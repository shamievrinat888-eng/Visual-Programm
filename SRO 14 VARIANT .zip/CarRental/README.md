# Car Rental System — прокат автомобилей (СРО №1, вариант 14)

Настольное приложение на **Java 17+ / JavaFX 21 / FXML (Scene Builder)**.

## Возможности
- Автомобили: добавление, редактирование (двойной клик), удаление, поиск (марка/модель/номер), фильтр по категории и «только свободные».
- Аренда: оформление с выбором дат, автоматический расчёт срока и стоимости (скидка 10% от 7 суток, 20% от 30 суток), возврат автомобиля, удаление записи, поиск.
- 13 демо-автомобилей и 5 демо-аренд; сохранение в CSV (`~/.carrental/`), автосохранение при выходе.
- MenuBar, ToolBar, строка состояния, горячие клавиши: Ctrl+N, Ctrl+E, Ctrl+D, Ctrl+R, Ctrl+S, Ctrl+F.
- Три окна: главное + формы «Автомобиль» и «Аренда»; диалоги Alert; валидация ввода.

## Запуск
Требуется JDK 17 или новее и Maven.

    mvn clean javafx:run

IntelliJ IDEA: File → Open → папка проекта (pom.xml) → справа Maven → Plugins → javafx → javafx:run.

## Структура
    src/main/java/com/carrental/App.java            — точка входа
    src/main/java/com/carrental/model/              — Car, Rental, DataStore (данные, CSV)
    src/main/java/com/carrental/controller/         — контроллеры окон
    src/main/resources/com/carrental/view/*.fxml    — интерфейс (открывается в Scene Builder)
    src/main/resources/com/carrental/style.css      — стили

Репозиторий: <вставьте ссылку на ваш GitHub>
