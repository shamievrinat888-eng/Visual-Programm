package com.carrental;

import com.carrental.model.DataStore;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class App extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        DataStore.getInstance().load();
        FXMLLoader loader = new FXMLLoader(App.class.getResource("/com/carrental/view/main.fxml"));
        Scene scene = new Scene(loader.load(), 1080, 680);
        scene.getStylesheets().add(App.class.getResource("/com/carrental/style.css").toExternalForm());
        stage.setTitle("Прокат автомобилей — Car Rental System");
        stage.setMinWidth(920);
        stage.setMinHeight(560);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void stop() {
        try {
            DataStore.getInstance().save();   // автосохранение при выходе
        } catch (IOException e) {
            System.err.println("Не удалось сохранить данные: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
