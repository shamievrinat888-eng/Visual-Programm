package com.carrental.util;

import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Вспомогательное форматирование дат и денег. */
public final class Fmt {
    public static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    private Fmt() { }

    public static String money(double value) {
        return String.format(Locale.forLanguageTag("ru-RU"), "%,.0f тг", value);
    }
}
