package com.carrental.model;

import javafx.beans.Observable;
import javafx.beans.property.*;

/** Автомобиль в парке проката. */
public class Car {
    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty brand = new SimpleStringProperty();
    private final StringProperty model = new SimpleStringProperty();
    private final StringProperty category = new SimpleStringProperty();
    private final IntegerProperty year = new SimpleIntegerProperty();
    private final StringProperty plate = new SimpleStringProperty();
    private final DoubleProperty pricePerDay = new SimpleDoubleProperty();
    private final BooleanProperty available = new SimpleBooleanProperty(true);

    public Car(int id, String brand, String model, String category, int year,
               String plate, double pricePerDay, boolean available) {
        this.id.set(id);
        this.brand.set(brand);
        this.model.set(model);
        this.category.set(category);
        this.year.set(year);
        this.plate.set(plate);
        this.pricePerDay.set(pricePerDay);
        this.available.set(available);
    }

    public int getId() { return id.get(); }
    public IntegerProperty idProperty() { return id; }

    public String getBrand() { return brand.get(); }
    public void setBrand(String v) { brand.set(v); }
    public StringProperty brandProperty() { return brand; }

    public String getModel() { return model.get(); }
    public void setModel(String v) { model.set(v); }
    public StringProperty modelProperty() { return model; }

    public String getCategory() { return category.get(); }
    public void setCategory(String v) { category.set(v); }
    public StringProperty categoryProperty() { return category; }

    public int getYear() { return year.get(); }
    public void setYear(int v) { year.set(v); }
    public IntegerProperty yearProperty() { return year; }

    public String getPlate() { return plate.get(); }
    public void setPlate(String v) { plate.set(v); }
    public StringProperty plateProperty() { return plate; }

    public double getPricePerDay() { return pricePerDay.get(); }
    public void setPricePerDay(double v) { pricePerDay.set(v); }
    public DoubleProperty pricePerDayProperty() { return pricePerDay; }

    public boolean isAvailable() { return available.get(); }
    public void setAvailable(boolean v) { available.set(v); }
    public BooleanProperty availableProperty() { return available; }

    /** Свойства, изменение которых должно обновлять FilteredList/TableView. */
    public Observable[] observables() {
        return new Observable[]{brand, model, category, year, plate, pricePerDay, available};
    }

    @Override
    public String toString() {
        return getBrand() + " " + getModel() + " (" + getPlate() + ")";
    }
}
