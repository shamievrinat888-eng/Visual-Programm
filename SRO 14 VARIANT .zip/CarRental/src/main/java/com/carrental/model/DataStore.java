package com.carrental.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Хранилище данных (в памяти) + сохранение в CSV в папке ~/.carrental. */
public final class DataStore {
    public static final List<String> CATEGORIES =
            List.of("Эконом", "Комфорт", "Бизнес", "Внедорожник", "Премиум", "Минивэн");

    private static final DataStore INSTANCE = new DataStore();

    private final ObservableList<Car> cars = FXCollections.observableArrayList(Car::observables);
    private final ObservableList<Rental> rentals = FXCollections.observableArrayList();
    private final Path dir = Paths.get(System.getProperty("user.home"), ".carrental");
    private int nextCarId = 1;
    private int nextRentalId = 1;
    private boolean loadFailed = false;

    private DataStore() { }

    public static DataStore getInstance() { return INSTANCE; }

    public ObservableList<Car> getCars() { return cars; }
    public ObservableList<Rental> getRentals() { return rentals; }
    public boolean isLoadFailed() { return loadFailed; }
    public Path getDir() { return dir; }

    public int nextCarId() { return nextCarId++; }
    public int nextRentalId() { return nextRentalId++; }

    public boolean hasActiveRental(Car car) {
        return rentals.stream().anyMatch(r -> r.getCar() == car && !r.isReturned());
    }

    public boolean hasAnyRental(Car car) {
        return rentals.stream().anyMatch(r -> r.getCar() == car);
    }

    public boolean isPlateTaken(String plate, Car except) {
        return cars.stream().anyMatch(c -> c != except && c.getPlate().equalsIgnoreCase(plate));
    }

    // ---------------- загрузка / сохранение ----------------

    public void load() {
        Path cf = dir.resolve("cars.csv");
        Path rf = dir.resolve("rentals.csv");
        cars.clear();
        rentals.clear();
        try {
            if (Files.exists(cf)) {
                loadCars(cf);
                if (Files.exists(rf)) loadRentals(rf);
            } else {
                loadDemo();
            }
        } catch (Exception e) {   // повреждённый файл — не падаем, берём демо-данные
            loadFailed = true;
            cars.clear();
            rentals.clear();
            nextCarId = 1;
            nextRentalId = 1;
            loadDemo();
        }
    }

    private void loadCars(Path file) throws IOException {
        List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        for (int i = 1; i < lines.size(); i++) {
            if (lines.get(i).isBlank()) continue;
            String[] p = lines.get(i).split(";", -1);
            Car c = new Car(Integer.parseInt(p[0]), p[1], p[2], p[3], Integer.parseInt(p[4]),
                    p[5], Double.parseDouble(p[6]), Boolean.parseBoolean(p[7]));
            cars.add(c);
            nextCarId = Math.max(nextCarId, c.getId() + 1);
        }
    }

    private void loadRentals(Path file) throws IOException {
        List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        for (int i = 1; i < lines.size(); i++) {
            if (lines.get(i).isBlank()) continue;
            String[] p = lines.get(i).split(";", -1);
            int carId = Integer.parseInt(p[1]);
            Car car = cars.stream().filter(c -> c.getId() == carId).findFirst().orElse(null);
            if (car == null) continue;
            Rental r = new Rental(Integer.parseInt(p[0]), car, p[2], p[3],
                    LocalDate.parse(p[4]), LocalDate.parse(p[5]),
                    Double.parseDouble(p[6]), Boolean.parseBoolean(p[7]));
            rentals.add(r);
            nextRentalId = Math.max(nextRentalId, r.getId() + 1);
        }
    }

    public void save() throws IOException {
        Files.createDirectories(dir);
        List<String> cl = new ArrayList<>();
        cl.add("id;brand;model;category;year;plate;pricePerDay;available");
        for (Car c : cars) {
            cl.add(String.join(";", String.valueOf(c.getId()), clean(c.getBrand()), clean(c.getModel()),
                    clean(c.getCategory()), String.valueOf(c.getYear()), clean(c.getPlate()),
                    String.valueOf(c.getPricePerDay()), String.valueOf(c.isAvailable())));
        }
        Files.write(dir.resolve("cars.csv"), cl, StandardCharsets.UTF_8);

        List<String> rl = new ArrayList<>();
        rl.add("id;carId;customer;phone;start;end;total;returned");
        for (Rental r : rentals) {
            rl.add(String.join(";", String.valueOf(r.getId()), String.valueOf(r.getCar().getId()),
                    clean(r.getCustomer()), clean(r.getPhone()), r.getStartDate().toString(),
                    r.getEndDate().toString(), String.valueOf(r.getTotal()), String.valueOf(r.isReturned())));
        }
        Files.write(dir.resolve("rentals.csv"), rl, StandardCharsets.UTF_8);
    }

    private static String clean(String s) {
        return s.replace(";", " ").replace("\n", " ").replace("\r", " ");
    }

    // ---------------- демо-данные (13 авто, 5 аренд) ----------------

    private void loadDemo() {
        addDemo("Hyundai", "Accent", "Эконом", 2020, "101 AAA 02", 12000, true);
        addDemo("Kia", "Rio", "Эконом", 2021, "102 BBB 02", 12500, false);
        addDemo("Chevrolet", "Nexia", "Эконом", 2019, "103 CCC 02", 9000, true);
        addDemo("Toyota", "Corolla", "Комфорт", 2022, "201 DDD 02", 16000, true);
        addDemo("Toyota", "Camry", "Бизнес", 2023, "202 EEE 02", 24000, true);
        addDemo("Hyundai", "Sonata", "Комфорт", 2021, "203 FFF 02", 18000, true);
        addDemo("Toyota", "RAV4", "Внедорожник", 2022, "301 GGG 02", 28000, false);
        addDemo("Kia", "Sportage", "Внедорожник", 2023, "302 HHH 02", 27000, true);
        addDemo("Toyota", "Land Cruiser Prado", "Внедорожник", 2021, "303 III 02", 45000, true);
        addDemo("Mercedes-Benz", "E-Class", "Премиум", 2022, "401 JJJ 02", 55000, false);
        addDemo("BMW", "5 Series", "Премиум", 2023, "402 KKK 02", 60000, true);
        addDemo("Toyota", "Alphard", "Минивэн", 2021, "501 LLL 02", 38000, true);
        addDemo("Hyundai", "Staria", "Минивэн", 2022, "502 MMM 02", 35000, true);

        LocalDate t = LocalDate.now();
        addDemoRental(2, "Алибек Сериков", "+7 701 123 45 67", t.minusDays(2), t.plusDays(3), false);
        addDemoRental(7, "Айгерим Нурлан", "+7 707 555 12 34", t.minusDays(1), t.plusDays(6), false);
        addDemoRental(10, "Дмитрий Иванов", "+7 777 888 99 00", t, t.plusDays(2), false);
        addDemoRental(4, "Мадина Омарова", "+7 705 222 33 44", t.minusDays(12), t.minusDays(5), true);
        addDemoRental(12, "Руслан Ахметов", "+7 747 111 22 33", t.minusDays(20), t.minusDays(10), true);
    }

    private void addDemo(String brand, String model, String cat, int year, String plate,
                         double price, boolean available) {
        cars.add(new Car(nextCarId++, brand, model, cat, year, plate, price, available));
    }

    private void addDemoRental(int carId, String name, String phone, LocalDate s, LocalDate e, boolean ret) {
        Car car = cars.stream().filter(c -> c.getId() == carId).findFirst().orElseThrow();
        double total = Rental.calcTotal(car.getPricePerDay(), Rental.daysBetween(s, e));
        rentals.add(new Rental(nextRentalId++, car, name, phone, s, e, total, ret));
    }
}
