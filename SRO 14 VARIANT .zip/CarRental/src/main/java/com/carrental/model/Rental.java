package com.carrental.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Запись об аренде автомобиля. */
public class Rental {
    private final int id;
    private final Car car;
    private final String customer;
    private final String phone;
    private final LocalDate startDate;
    private final LocalDate endDate;
    private final double total;
    private boolean returned;

    public Rental(int id, Car car, String customer, String phone,
                  LocalDate startDate, LocalDate endDate, double total, boolean returned) {
        this.id = id;
        this.car = car;
        this.customer = customer;
        this.phone = phone;
        this.startDate = startDate;
        this.endDate = endDate;
        this.total = total;
        this.returned = returned;
    }

    /** Количество суток аренды. */
    public static int daysBetween(LocalDate start, LocalDate end) {
        return (int) ChronoUnit.DAYS.between(start, end);
    }

    /** Скидка: от 7 суток — 10%, от 30 суток — 20%. */
    public static double discount(int days) {
        if (days >= 30) return 0.20;
        if (days >= 7) return 0.10;
        return 0.0;
    }

    public static double calcTotal(double pricePerDay, int days) {
        return Math.round(pricePerDay * days * (1.0 - discount(days)));
    }

    public int getId() { return id; }
    public Car getCar() { return car; }
    public String getCustomer() { return customer; }
    public String getPhone() { return phone; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public double getTotal() { return total; }
    public boolean isReturned() { return returned; }
    public void setReturned(boolean returned) { this.returned = returned; }
    public int getDays() { return daysBetween(startDate, endDate); }

    public String getStatusText() {
        if (returned) return "Возвращена";
        if (endDate.isBefore(LocalDate.now())) return "Просрочена";
        return "Активна";
    }
}
