package com.carrental.controller;

import com.carrental.model.Car;
import com.carrental.model.DataStore;
import com.carrental.model.Rental;
import com.carrental.util.Fmt;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Region;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Форма оформления аренды с расчётом стоимости. */
public class RentalFormController {
    @FXML private ComboBox<Car> carBox;
    @FXML private TextField customerField;
    @FXML private TextField phoneField;
    @FXML private DatePicker startPicker;
    @FXML private DatePicker endPicker;
    @FXML private Label daysLabel;
    @FXML private Label discountLabel;
    @FXML private Label totalLabel;
    @FXML private Label errorLabel;

    private final DataStore store = DataStore.getInstance();
    private Rental result;

    @FXML
    private void initialize() {
        List<Car> free = new ArrayList<>();
        for (Car c : store.getCars()) if (c.isAvailable()) free.add(c);
        carBox.setItems(FXCollections.observableArrayList(free));
        carBox.setConverter(new StringConverter<Car>() {
            @Override
            public String toString(Car c) {
                return c == null ? "" : c + " — " + c.getCategory() + ", " + Fmt.money(c.getPricePerDay()) + "/сут";
            }

            @Override
            public Car fromString(String s) {
                return null;
            }
        });

        startPicker.setEditable(false);
        endPicker.setEditable(false);
        startPicker.setValue(LocalDate.now());
        endPicker.setValue(LocalDate.now().plusDays(1));

        carBox.valueProperty().addListener((o, a, b) -> updatePreview());
        startPicker.valueProperty().addListener((o, a, b) -> updatePreview());
        endPicker.valueProperty().addListener((o, a, b) -> updatePreview());
        updatePreview();
    }

    public void setPreselected(Car car) {
        if (car != null && car.isAvailable()) carBox.setValue(car);
    }

    public Rental getResult() {
        return result;
    }

    private void updatePreview() {
        Car car = carBox.getValue();
        LocalDate s = startPicker.getValue();
        LocalDate e = endPicker.getValue();
        if (car == null || s == null || e == null || !e.isAfter(s)) {
            daysLabel.setText("—");
            discountLabel.setText("—");
            totalLabel.setText("—");
            return;
        }
        int days = Rental.daysBetween(s, e);
        daysLabel.setText(String.valueOf(days));
        discountLabel.setText((int) (Rental.discount(days) * 100) + "%");
        totalLabel.setText(Fmt.money(Rental.calcTotal(car.getPricePerDay(), days)));
    }

    @FXML
    private void onSave() {
        List<String> errors = new ArrayList<>();
        Car car = carBox.getValue();
        String customer = customerField.getText().trim();
        String phone = phoneField.getText().trim();
        LocalDate s = startPicker.getValue();
        LocalDate e = endPicker.getValue();

        if (car == null) errors.add("Выберите автомобиль.");
        if (customer.length() < 3 || customer.length() > 50 || !customer.matches("^[\\p{L} .'-]+$")) {
            errors.add("ФИО клиента: 3–50 символов, только буквы.");
        }
        if (!phone.matches("^\\+?[0-9 ()-]{7,18}$")) {
            errors.add("Телефон: 7–18 символов (цифры, +, пробел, скобки, дефис).");
        }
        if (s == null || e == null) {
            errors.add("Укажите даты начала и окончания аренды.");
        } else {
            if (s.isBefore(LocalDate.now())) errors.add("Дата начала не может быть в прошлом.");
            if (!e.isAfter(s)) errors.add("Дата окончания должна быть позже даты начала.");
            else if (Rental.daysBetween(s, e) > 365) errors.add("Максимальный срок аренды — 365 суток.");
        }

        if (!errors.isEmpty()) {
            showErrors(errors);
            return;
        }

        int days = Rental.daysBetween(s, e);
        double total = Rental.calcTotal(car.getPricePerDay(), days);
        result = new Rental(store.nextRentalId(), car, customer, phone, s, e, total, false);
        close();
    }

    @FXML
    private void onCancel() {
        result = null;
        close();
    }

    private void showErrors(List<String> errors) {
        errorLabel.setText(String.join("\n", errors));
        errorLabel.setMinHeight(Region.USE_PREF_SIZE);
        Platform.runLater(() -> errorLabel.getScene().getWindow().sizeToScene());
    }

    private void close() {
        ((Stage) customerField.getScene().getWindow()).close();
    }
}
