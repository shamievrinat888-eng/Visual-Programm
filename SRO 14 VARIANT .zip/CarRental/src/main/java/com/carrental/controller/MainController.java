package com.carrental.controller;

import com.carrental.model.Car;
import com.carrental.model.DataStore;
import com.carrental.model.Rental;
import com.carrental.util.Fmt;
import javafx.application.Platform;
import javafx.beans.property.ReadOnlyDoubleWrapper;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;

/** Контроллер главного окна. */
public class MainController {
    private static final String ALL = "Все категории";

    @FXML private TabPane tabPane;
    @FXML private TextField searchField;
    @FXML private TextField rentalSearchField;
    @FXML private ComboBox<String> categoryFilter;
    @FXML private CheckBox onlyAvailableCheck;

    @FXML private TableView<Car> carTable;
    @FXML private TableColumn<Car, Number> colId;
    @FXML private TableColumn<Car, String> colBrand;
    @FXML private TableColumn<Car, String> colModel;
    @FXML private TableColumn<Car, String> colCategory;
    @FXML private TableColumn<Car, Number> colYear;
    @FXML private TableColumn<Car, String> colPlate;
    @FXML private TableColumn<Car, Number> colPrice;
    @FXML private TableColumn<Car, Boolean> colStatus;

    @FXML private TableView<Rental> rentalTable;
    @FXML private TableColumn<Rental, Number> rColId;
    @FXML private TableColumn<Rental, String> rColCar;
    @FXML private TableColumn<Rental, String> rColCustomer;
    @FXML private TableColumn<Rental, String> rColPhone;
    @FXML private TableColumn<Rental, String> rColStart;
    @FXML private TableColumn<Rental, String> rColEnd;
    @FXML private TableColumn<Rental, Number> rColDays;
    @FXML private TableColumn<Rental, Number> rColTotal;
    @FXML private TableColumn<Rental, String> rColStatus;

    @FXML private Label statusLabel;
    @FXML private Label countLabel;

    private final DataStore store = DataStore.getInstance();
    private FilteredList<Car> filteredCars;
    private FilteredList<Rental> filteredRentals;

    @FXML
    private void initialize() {
        setupCarTable();
        setupRentalTable();

        categoryFilter.getItems().add(ALL);
        categoryFilter.getItems().addAll(DataStore.CATEGORIES);
        categoryFilter.getSelectionModel().selectFirst();

        searchField.textProperty().addListener((o, a, b) -> applyCarFilter());
        categoryFilter.valueProperty().addListener((o, a, b) -> applyCarFilter());
        onlyAvailableCheck.selectedProperty().addListener((o, a, b) -> applyCarFilter());
        rentalSearchField.textProperty().addListener((o, a, b) -> applyRentalFilter());

        store.getCars().addListener((ListChangeListener<Car>) c -> updateCounters());
        store.getRentals().addListener((ListChangeListener<Rental>) c -> updateCounters());
        updateCounters();

        carTable.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && carTable.getSelectionModel().getSelectedItem() != null) {
                onEditCar();
            }
        });

        setStatus("Готово. Загружено автомобилей: " + store.getCars().size());

        if (store.isLoadFailed()) {
            Platform.runLater(() -> alert(Alert.AlertType.WARNING, "Загрузка данных",
                    "Файлы данных повреждены. Загружены демонстрационные данные."));
        }
    }

    // ---------------- настройка таблиц ----------------

    private void setupCarTable() {
        colId.setCellValueFactory(d -> d.getValue().idProperty());
        colBrand.setCellValueFactory(d -> d.getValue().brandProperty());
        colModel.setCellValueFactory(d -> d.getValue().modelProperty());
        colCategory.setCellValueFactory(d -> d.getValue().categoryProperty());
        colYear.setCellValueFactory(d -> d.getValue().yearProperty());
        colPlate.setCellValueFactory(d -> d.getValue().plateProperty());
        colPrice.setCellValueFactory(d -> d.getValue().pricePerDayProperty());
        colStatus.setCellValueFactory(d -> d.getValue().availableProperty());

        colPrice.setCellFactory(col -> new TableCell<Car, Number>() {
            @Override
            protected void updateItem(Number v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : Fmt.money(v.doubleValue()));
            }
        });
        colStatus.setCellFactory(col -> new TableCell<Car, Boolean>() {
            @Override
            protected void updateItem(Boolean free, boolean empty) {
                super.updateItem(free, empty);
                if (empty || free == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(free ? "Свободен" : "Занят");
                    setStyle(free ? "-fx-text-fill: #1b8a3a;" : "-fx-text-fill: #c0392b;");
                }
            }
        });

        filteredCars = new FilteredList<>(store.getCars(), c -> true);
        SortedList<Car> sorted = new SortedList<>(filteredCars);
        sorted.comparatorProperty().bind(carTable.comparatorProperty());
        carTable.setItems(sorted);
    }

    private void setupRentalTable() {
        rColId.setCellValueFactory(d -> new ReadOnlyIntegerWrapper(d.getValue().getId()));
        rColCar.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getCar().toString()));
        rColCustomer.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getCustomer()));
        rColPhone.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getPhone()));
        rColStart.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getStartDate().format(Fmt.DATE)));
        rColEnd.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getEndDate().format(Fmt.DATE)));
        rColDays.setCellValueFactory(d -> new ReadOnlyIntegerWrapper(d.getValue().getDays()));
        rColTotal.setCellValueFactory(d -> new ReadOnlyDoubleWrapper(d.getValue().getTotal()));
        rColStatus.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getStatusText()));

        rColTotal.setCellFactory(col -> new TableCell<Rental, Number>() {
            @Override
            protected void updateItem(Number v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : Fmt.money(v.doubleValue()));
            }
        });
        rColStatus.setCellFactory(col -> new TableCell<Rental, String>() {
            @Override
            protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                if (empty || s == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(s);
                    String color;
                    switch (s) {
                        case "Активна": color = "#1b8a3a"; break;
                        case "Просрочена": color = "#c0392b"; break;
                        default: color = "#7f8c8d";
                    }
                    setStyle("-fx-text-fill: " + color + ";");
                }
            }
        });

        filteredRentals = new FilteredList<>(store.getRentals(), r -> true);
        SortedList<Rental> sorted = new SortedList<>(filteredRentals);
        sorted.comparatorProperty().bind(rentalTable.comparatorProperty());
        rentalTable.setItems(sorted);
    }

    // ---------------- фильтры ----------------

    private void applyCarFilter() {
        String q = searchField.getText() == null ? "" : searchField.getText().trim().toLowerCase();
        String cat = categoryFilter.getValue();
        boolean onlyFree = onlyAvailableCheck.isSelected();
        filteredCars.setPredicate(c -> {
            boolean textOk = q.isEmpty()
                    || c.getBrand().toLowerCase().contains(q)
                    || c.getModel().toLowerCase().contains(q)
                    || c.getPlate().toLowerCase().contains(q);
            boolean catOk = cat == null || cat.equals(ALL) || c.getCategory().equals(cat);
            boolean freeOk = !onlyFree || c.isAvailable();
            return textOk && catOk && freeOk;
        });
        setStatus("Найдено автомобилей: " + filteredCars.size());
    }

    private void applyRentalFilter() {
        String q = rentalSearchField.getText() == null ? "" : rentalSearchField.getText().trim().toLowerCase();
        filteredRentals.setPredicate(r -> q.isEmpty()
                || r.getCustomer().toLowerCase().contains(q)
                || r.getPhone().toLowerCase().contains(q)
                || r.getCar().toString().toLowerCase().contains(q));
        setStatus("Найдено аренд: " + filteredRentals.size());
    }

    @FXML
    private void onResetFilters() {
        searchField.clear();
        rentalSearchField.clear();
        categoryFilter.getSelectionModel().selectFirst();
        onlyAvailableCheck.setSelected(false);
        setStatus("Фильтры сброшены");
    }

    @FXML
    private void onFocusSearch() {
        tabPane.getSelectionModel().select(0);
        searchField.requestFocus();
    }

    // ---------------- действия с автомобилями ----------------

    @FXML
    private void onAddCar() {
        Car result = openCarForm(null);
        if (result != null) {
            store.getCars().add(result);
            carTable.getSelectionModel().select(result);
            tabPane.getSelectionModel().select(0);
            setStatus("Добавлен автомобиль: " + result);
        }
    }

    @FXML
    private void onEditCar() {
        Car selected = carTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            tabPane.getSelectionModel().select(0);
            alert(Alert.AlertType.INFORMATION, "Редактирование", "Выберите автомобиль в таблице.");
            return;
        }
        Car result = openCarForm(selected);
        if (result != null) {
            carTable.refresh();
            rentalTable.refresh();
            setStatus("Изменён автомобиль: " + result);
        }
    }

    @FXML
    private void onDelete() {
        if (tabPane.getSelectionModel().getSelectedIndex() == 0) {
            deleteCar();
        } else {
            deleteRental();
        }
    }

    private void deleteCar() {
        Car car = carTable.getSelectionModel().getSelectedItem();
        if (car == null) {
            alert(Alert.AlertType.INFORMATION, "Удаление", "Выберите автомобиль в таблице.");
            return;
        }
        if (store.hasAnyRental(car)) {
            alert(Alert.AlertType.WARNING, "Удаление невозможно",
                    "Для автомобиля есть записи об аренде.\nСначала удалите их на вкладке «Аренда».");
            return;
        }
        if (confirm("Удаление", "Удалить автомобиль " + car + "?")) {
            store.getCars().remove(car);
            setStatus("Автомобиль удалён: " + car);
        }
    }

    private void deleteRental() {
        Rental r = rentalTable.getSelectionModel().getSelectedItem();
        if (r == null) {
            alert(Alert.AlertType.INFORMATION, "Удаление", "Выберите запись об аренде.");
            return;
        }
        if (confirm("Удаление", "Удалить запись об аренде №" + r.getId() + " (" + r.getCustomer() + ")?")) {
            if (!r.isReturned()) r.getCar().setAvailable(true);
            store.getRentals().remove(r);
            setStatus("Запись об аренде удалена");
        }
    }

    // ---------------- аренда ----------------

    @FXML
    private void onRent() {
        boolean anyFree = store.getCars().stream().anyMatch(Car::isAvailable);
        if (!anyFree) {
            alert(Alert.AlertType.WARNING, "Оформление аренды", "Нет свободных автомобилей.");
            return;
        }
        Car preselected = carTable.getSelectionModel().getSelectedItem();
        Rental result = openRentalForm(preselected);
        if (result != null) {
            result.getCar().setAvailable(false);
            store.getRentals().add(result);
            tabPane.getSelectionModel().select(1);
            rentalTable.getSelectionModel().select(result);
            setStatus("Оформлена аренда №" + result.getId() + " на сумму " + Fmt.money(result.getTotal()));
        }
    }

    @FXML
    private void onReturnCar() {
        Rental r = rentalTable.getSelectionModel().getSelectedItem();
        if (r == null) {
            tabPane.getSelectionModel().select(1);
            alert(Alert.AlertType.INFORMATION, "Возврат автомобиля", "Выберите аренду в таблице.");
            return;
        }
        if (r.isReturned()) {
            alert(Alert.AlertType.INFORMATION, "Возврат автомобиля", "Этот автомобиль уже возвращён.");
            return;
        }
        if (confirm("Возврат автомобиля", "Принять автомобиль " + r.getCar() + " от клиента " + r.getCustomer() + "?")) {
            r.setReturned(true);
            r.getCar().setAvailable(true);
            rentalTable.refresh();
            setStatus("Автомобиль возвращён: " + r.getCar());
        }
    }

    // ---------------- файл / справка ----------------

    @FXML
    private void onSave() {
        try {
            store.save();
            setStatus("Данные сохранены в " + store.getDir());
        } catch (IOException e) {
            alert(Alert.AlertType.ERROR, "Ошибка сохранения", "Не удалось сохранить данные:\n" + e.getMessage());
        }
    }

    @FXML
    private void onExit() {
        if (confirm("Выход", "Сохранить данные и выйти из программы?")) {
            Platform.exit();   // App.stop() выполнит автосохранение
        }
    }

    @FXML
    private void onAbout() {
        alert(Alert.AlertType.INFORMATION, "О программе",
                "Car Rental System — прокат автомобилей\n"
                        + "СРО №1, «Визуальное программирование»\n"
                        + "Java + JavaFX + FXML (Scene Builder)\n\n"
                        + "Скидка: от 7 суток — 10%, от 30 суток — 20%.\n"
                        + "Горячие клавиши: Ctrl+N, Ctrl+E, Ctrl+D, Ctrl+R, Ctrl+S, Ctrl+F.");
    }

    // ---------------- вспомогательные методы ----------------

    private Car openCarForm(Car car) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/carrental/view/car-form.fxml"));
            Parent root = loader.load();
            CarFormController c = loader.getController();
            c.setCar(car);
            showModal(root, car == null ? "Новый автомобиль" : "Редактирование автомобиля");
            return c.getResult();
        } catch (IOException e) {
            alert(Alert.AlertType.ERROR, "Ошибка", "Не удалось открыть форму:\n" + e.getMessage());
            return null;
        }
    }

    private Rental openRentalForm(Car preselected) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/carrental/view/rental-form.fxml"));
            Parent root = loader.load();
            RentalFormController c = loader.getController();
            c.setPreselected(preselected);
            showModal(root, "Оформление аренды");
            return c.getResult();
        } catch (IOException e) {
            alert(Alert.AlertType.ERROR, "Ошибка", "Не удалось открыть форму:\n" + e.getMessage());
            return null;
        }
    }

    private void showModal(Parent root, String title) {
        Stage stage = new Stage();
        stage.setTitle(title);
        stage.initOwner(window());
        stage.initModality(Modality.WINDOW_MODAL);
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/com/carrental/style.css").toExternalForm());
        stage.setScene(scene);
        stage.setResizable(false);
        stage.showAndWait();
    }

    private Window window() {
        return tabPane.getScene().getWindow();
    }

    private void alert(Alert.AlertType type, String title, String message) {
        Alert a = new Alert(type);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(message);
        a.initOwner(window());
        a.showAndWait();
    }

    private boolean confirm(String title, String message) {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION, message, ButtonType.YES, ButtonType.NO);
        a.setTitle(title);
        a.setHeaderText(null);
        a.initOwner(window());
        return a.showAndWait().filter(b -> b == ButtonType.YES).isPresent();
    }

    private void setStatus(String text) {
        statusLabel.setText(text);
    }

    private void updateCounters() {
        long free = store.getCars().stream().filter(Car::isAvailable).count();
        double revenue = store.getRentals().stream().mapToDouble(Rental::getTotal).sum();
        countLabel.setText(String.format("Автомобилей: %d (свободно: %d)  |  Аренд: %d  |  Сумма аренд: %s",
                store.getCars().size(), free, store.getRentals().size(), Fmt.money(revenue)));
    }
}
