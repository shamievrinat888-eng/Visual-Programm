package com.carrental.controller;

import com.carrental.model.Car;
import com.carrental.model.DataStore;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Форма добавления / редактирования автомобиля. */
public class CarFormController {
    @FXML private Label titleLabel;
    @FXML private TextField brandField;
    @FXML private TextField modelField;
    @FXML private ComboBox<String> categoryBox;
    @FXML private ComboBox<Integer> yearBox;
    @FXML private TextField plateField;
    @FXML private TextField priceField;
    @FXML private CheckBox availableCheck;
    @FXML private Label errorLabel;

    private final DataStore store = DataStore.getInstance();
    private Car car;          // null — режим добавления
    private Car result;

    @FXML
    private void initialize() {
        categoryBox.setItems(FXCollections.observableArrayList(DataStore.CATEGORIES));
        categoryBox.getSelectionModel().selectFirst();

        int current = LocalDate.now().getYear();
        List<Integer> years = new ArrayList<>();
        for (int y = current + 1; y >= 1990; y--) years.add(y);
        yearBox.setItems(FXCollections.observableArrayList(years));
        yearBox.setValue(current - 2);
        availableCheck.setSelected(true);
    }

    public void setCar(Car car) {
        this.car = car;
        if (car == null) return;
        titleLabel.setText("Редактирование автомобиля");
        brandField.setText(car.getBrand());
        modelField.setText(car.getModel());
        categoryBox.setValue(car.getCategory());
        yearBox.setValue(car.getYear());
        plateField.setText(car.getPlate());
        priceField.setText(String.valueOf((long) car.getPricePerDay()));
        availableCheck.setSelected(car.isAvailable());
        if (store.hasActiveRental(car)) {
            availableCheck.setDisable(true);   // авто в аренде — статус менять нельзя
        }
    }

    public Car getResult() {
        return result;
    }

    @FXML
    private void onSave() {
        List<String> errors = new ArrayList<>();

        String brand = brandField.getText().trim();
        String model = modelField.getText().trim();
        String plate = plateField.getText().trim().toUpperCase();

        if (brand.isEmpty() || brand.length() > 30) errors.add("Марка: от 1 до 30 символов.");
        if (model.isEmpty() || model.length() > 30) errors.add("Модель: от 1 до 30 символов.");
        if (categoryBox.getValue() == null) errors.add("Выберите категорию.");
        if (yearBox.getValue() == null) errors.add("Выберите год выпуска.");

        if (!plate.matches("^[A-ZА-Я0-9 \\-]{4,12}$")) {
            errors.add("Гос. номер: 4–12 символов (буквы, цифры, пробел, дефис).");
        } else if (store.isPlateTaken(plate, car)) {
            errors.add("Автомобиль с таким номером уже есть в парке.");
        }

        double price = 0;
        try {
            price = Double.parseDouble(priceField.getText().trim().replace(",", ".").replace(" ", ""));
            if (!Double.isFinite(price) || price <= 0 || price > 1_000_000) {
                errors.add("Цена за сутки: число от 1 до 1 000 000.");
            }
        } catch (NumberFormatException e) {
            errors.add("Цена за сутки должна быть числом.");
        }

        if (!errors.isEmpty()) {
            showErrors(errors);
            return;
        }

        if (car == null) {
            result = new Car(store.nextCarId(), brand, model, categoryBox.getValue(), yearBox.getValue(),
                    plate, price, availableCheck.isSelected());
        } else {
            car.setBrand(brand);
            car.setModel(model);
            car.setCategory(categoryBox.getValue());
            car.setYear(yearBox.getValue());
            car.setPlate(plate);
            car.setPricePerDay(price);
            if (!availableCheck.isDisabled()) car.setAvailable(availableCheck.isSelected());
            result = car;
        }
        close();
    }

    @FXML
    private void onCancel() {
        result = null;
        close();
    }

    private void showErrors(List<String> errors) {
        errorLabel.setText(String.join("\n", errors));
        errorLabel.setMinHeight(Region.USE_PREF_SIZE);
        Platform.runLater(() -> errorLabel.getScene().getWindow().sizeToScene());
    }

    private void close() {
        ((Stage) brandField.getScene().getWindow()).close();
    }
}
